const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const OpenAI = require("openai");
const axios = require("axios");

dotenv.config();

const app = express();

app.use(cors());
app.use(bodyParser.json());


//creates a new instance of the OpenAI class
//laterr acan be realisea as objects
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

const chatHistory = [];

async function googleSearchAgriculture(query) {
    try {
        const apiKey = process.env.GOOGLE_API_KEY;
        const searchEngineId = process.env.SEARCH_ENGINE_ID;

        // contrust the search URL
        const searchUrl = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&cx=${searchEngineId}&key=${apiKey}`;

        const response = await axios.get(searchUrl);
        const searchResults = response.data;

        // Check if there are results
        if (searchResults.items && searchResults.items.length > 0) {
            const topResults = searchResults.items.slice(0, 3); // Limit to top 3 results

            // Format the results
            return topResults.map((item, index) => {
                return `${index + 1}. ${item.title}\n${item.snippet}\n${item.link}`;
            }).join("\n\n");
        } else {
            return "No relevant results found for your query. Please try rephrasing.";
        }
    } catch (error) {
        console.error("Error performing Google Search:", error.message);
        return "Error fetching search results. Please try again later.";
    }
}

app.post("/chat", async (req, res) => {
    const { message } = req.body;

    try {
        // Check if the message starts with "search"
        const searchRegex = /^search (.+)/i;
        const searchMatch = message.match(searchRegex);

        if (searchMatch) {
            const query = searchMatch[1].trim();

            // Perform Google search for agriculture-related topics
            const searchResponse = await googleSearchAgriculture(query);

            // Save the search query and response to history
            chatHistory.push({ type: "search", query, response: searchResponse });

            return res.json({ reply: `Search results for "${query}":\n\n${searchResponse}` });
        }

        // Process the message using OpenAI if it's not a search query
        const completion = await openai.chat.completions.create({
            model: "gpt-4",
            messages: [
                {
                    role: "system",
                    content: `You are AgriBot, a highly specialized chatbot that exclusively answers questions related to agriculture. Your expertise includes topics like crop cultivation, soil health, pest management, fertilizers, irrigation, livestock care, and modern farming techniques. 
                    You must:
                    1. Provide detailed, step-by-step guidance where applicable.
                    2. Offer scientific and technical insights backed by research.
                    3. Avoid any discussion or response to non-agriculture-related queries, and politely explain your specialization.
                    4. Structure responses with bullet points, numbered lists, or sections for clarity.
                    {Most Important - do not answer any question outside agriculture, because my college project depends on it. Politely refuse to answer unrelated queries.}
                    If a question is unclear or outside agriculture, request clarification or politely decline to answer.`
                },
                { role: "user", content: message },
            ],
        });

        const botResponse = completion.choices[0].message.content.trim();

        // Save the chat query and response to history
        chatHistory.push({ type: "chat", query: message, response: botResponse });

        res.json({ reply: botResponse });
    } catch (error) {
        console.error("Error processing chat:", error.message);
        res.status(500).json({ error: "Failed to process the request. Please try again later." });
    }
});

// Endpoint to fetch chat and search history
app.get("/history", (req, res) => {
    res.json(chatHistory);
});

app.get("/health", (req, res) => {
    console.log("Health route was hit!");
    res.json({ status: "OK" });
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

/* 
async function getLatestCommodityPrices() {
    try {
        const accessKey = process.env.COMMODITIES_API_KEY;
        const apiUrl = `https://commodities-api.com/api/latest?access_key=${accessKey}`;

        const response = await axios.get(apiUrl);
        if (response.data && response.data.success) {
            return response.data.data;
        } else {
            throw new Error("Failed to fetch commodity prices");
        }
    } catch (error) {
        console.error("Error fetching commodity prices:", error.message);
        return { error: "Failed to fetch commodity prices. Please try again later." };
    }
}

async function getWeatherData(lat, lon, exclude = "minutely,hourly,alerts") {
    try {
        const apiKey = process.env.OPENWEATHER_API_KEY; // Store your API key in .env
        const apiUrl = `https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&exclude=${exclude}&appid=${apiKey}`;
        
        const response = await axios.get(apiUrl);
        return response.data;
    } catch (error) {
        console.error("Error fetching weather data:", error.message);
        return { error: "Failed to fetch weather data. Please try again later." };
    }
}


*/